
# Fully qualified module
import project.bar

# Fully qualified package
import project.sub1

# Relative module
import bli

# Relative package
import sub2

# Not found.
import project.alien
import project.alien.alien2

# More than one level and relative.
import sub1.test
 
