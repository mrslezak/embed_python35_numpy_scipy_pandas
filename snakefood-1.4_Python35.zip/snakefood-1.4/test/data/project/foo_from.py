
# Fully qualified module
from project import bar

# Fully qualified package
from project import sub1

# Not found.
from project import alien_sym


