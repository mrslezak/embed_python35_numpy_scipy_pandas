#!/usr/bin/env python
"""
Test with invalid code.
"""

def incomplete():
    

FIXME




