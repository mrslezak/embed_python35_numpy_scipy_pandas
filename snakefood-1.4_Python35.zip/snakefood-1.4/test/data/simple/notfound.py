#!/usr/bin/env python

# Module that cannot be found.
import alien_module_yeah

# Package that cannot be found.
import alien_package.alien_module

# From variants.
from alien_module_yeah import alien_symbol
from alien_package import alien_module
