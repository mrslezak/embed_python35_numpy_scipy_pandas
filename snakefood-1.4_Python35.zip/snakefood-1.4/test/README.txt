This is the automated test suite for snakefood.
Run it like this::

  py.test

or::

  nosetests

Thanks.
