These are manpages provided by 
"Sandro Tosi" <morph@debian.org> 
for inclusion into the Debian distro.

